<?php

class DATABASE_CONFIG {



	var $default = array(

		'datasource' => 'Database/Mysql',

		'persistent' => false,

		'host' => 'localhost',

		'login' => 'k2157616_creazi',

		'password' => 'konohagakure',

		'database' => 'k2157616_webomatics',

		'prefix' => 'cms_',

	);

}

?>